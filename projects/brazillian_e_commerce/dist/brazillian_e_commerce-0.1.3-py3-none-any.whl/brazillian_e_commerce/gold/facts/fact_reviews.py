# from pyspark.sql.functions import col

# def build_fact_reviews(reviews_df):
#     return (
#         reviews_df
#         .select(
#             col("review_id"),
#             col("order_id"),
#             col("review_score")
#         )
#     )
