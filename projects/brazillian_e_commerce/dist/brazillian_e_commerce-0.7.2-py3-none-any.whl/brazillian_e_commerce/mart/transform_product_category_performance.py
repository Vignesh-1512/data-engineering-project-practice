from pyspark.sql.functions import (
    col,
    sum as _sum,
    countDistinct,
    to_date
)

def build_product_category_performance(**tables):
    """
    FINAL: Product Category Performance (BR-5)
    Grain: sales_date + product_category
    """

    fact_sales=tables["fact_sales"]
    fact_orders=tables["fact_orders"]
    dim_products=tables["dim_products"]
    dim_date=tables["dim_date"]

    df = (
        fact_sales
        .join(fact_orders, "order_id", "inner")
        .join(dim_products, "product_id", "left")
        .withColumn(
            "sales_date",
            to_date(col("order_purchase_ts"))
        )
        .join(
            dim_date,
            col("sales_date") == dim_date.date,
            "left"
        )
    )

    result = (
        df.groupBy(
            col("sales_date"),
            col("product_category")
        )
        .agg(
            _sum("revenue").alias("total_revenue"),
            countDistinct("order_id").alias("total_orders")
        )
        .withColumn(
            "avg_order_value",
            col("total_revenue") / col("total_orders")
        )
    )

    return result
