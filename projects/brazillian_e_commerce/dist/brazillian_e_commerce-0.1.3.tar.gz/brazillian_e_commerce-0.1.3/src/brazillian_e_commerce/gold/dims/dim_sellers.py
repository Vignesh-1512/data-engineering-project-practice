# from pyspark.sql.functions import col

# def build_dim_sellers(sellers_df):
#     return (
#         sellers_df
#         .select(
#             col("seller_id"),
#             col("seller_city"),
#             col("seller_state")
#         )
#     )
