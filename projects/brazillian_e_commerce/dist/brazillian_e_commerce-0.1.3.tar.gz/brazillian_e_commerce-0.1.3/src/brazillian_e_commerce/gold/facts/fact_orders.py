# from pyspark.sql.functions import col


# def build_fact_orders(orders_df):
#     """
#     FACT: Orders
#     Grain: 1 row per order
#     """

#     return (
#         orders_df
#         .select(
#             col("order_id"),
#             col("customer_id"),
#             col("order_status"),
#             col("order_purchase_ts"),
#             col("order_delivered_customer_ts").alias("order_delivered_ts"),
#             col("order_estimated_delivery_ts").alias("order_estimated_delivery_ts")
#         )
#     )
